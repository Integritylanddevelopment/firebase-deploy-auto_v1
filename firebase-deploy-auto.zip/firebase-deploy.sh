#!/bin/bash
echo "[+] Ensuring Firebase public directory exists..."
mkdir -p public
echo "<!DOCTYPE html><html><body><h1>Firebase Deployed</h1></body></html>" > public/index.html

echo "[+] Creating firebase.json if missing..."
cat <<EOF > firebase.json
{
  "hosting": {
    "public": "public",
    "ignore": ["firebase.json", "**/.*", "**/node_modules/**"]
  }
}
EOF

echo "[+] Deploying to Firebase..."
firebase deploy
